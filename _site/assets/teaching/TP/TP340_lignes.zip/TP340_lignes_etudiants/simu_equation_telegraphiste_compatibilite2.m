%% TP UE 340 - simulation équation des télégraphistes

clear all ; close ;
%% 1) Déclaration des paramètres de la ligne

global l c r g n Delta largeur Ta

l = 2.5e-7;     % inductance linéique (H/m)
c = 1e-10;     % capacité linéique (F/m)
r = 0.04;     % résistance linéique (série, Ohm/m)
g = 0;     % conductance linéique (parallèle, S/m)
L = 100;     % longueur de la ligne (m)
%% 2) Paramètres de discrétisation
% 

n = 300 ;       % nombre de points de discrétisation spatiale

cel = 1/sqrt(l*c);      % vitesse de l'onde (dans un cable sans perte)
Ta = L/cel;             % Temps mis par l'onde pour parcourir la ligne
Tf = Ta*1.95  ;         % temps de simulation (s). 
                        % Le paramètre à choisir correspond au nombre d'aller retour de l'onde dans le câble
dx = L/(n-1);           % longueur d'un tronçon élémentaire discrétisé
%% 3) Paramètre du signal

largeur=0.1;    % Largeur de l'impulsion (par rapport au temps de parcours de l'onde)
%% 3) Formulation et résolution du problème numérique
% 
% 
% On choisit de résoudre l'équation des télégraphistes sur la tension par la 
% méthode des différences finies. 
% 
% On discrétise la ligne en plusieurs petit tronçons de longueur $\textrm{dx}$, 
% et on s'intéresse à la valeur de la solution à la jonction de chaque tronçon. 
% On peut discrétiser l'opérateur Laplacien . Il devient équivalent à une matrice 
% $\Delta \;$:

% Matrice Laplacien discrétisé :

Delta= ... % à remplir !
%% 
% _*A noter*_ : il faut aussi tenir compte des conditions limites, c'est à dire 
% de la valeur des noeuds à l'extrémité du domaine. On considèrera ces valeurs 
% imposées (conditions de Dirichlet).

Delta=Delta(2:end-1,:); % lié aux conditions limites, ne pas toucher.
%% 
% Ensuite, il faut réécrire problème sous la forme d'un problème de Cauchy afin 
% de pouvoir y appliquer les solveurs standards.
% 
% On peut utiliser directement la fonction décrite en annexe, pour la résolution 
% du système.

options=odeset('InitialStep',Tf/1e3,'Stats','on','MaxStep',Tf/50,'RelTol',1e-4,"AbsTol",1e-7); % Options de résolution
tic
[t,y] = ode113(@ODE_telegraphistes, [0 Tf],zeros(2*(n-2),1),options);   % Solveur Matlab
toc
%% 4) Tracé du résultat
% 

x=(1:n-2)/n*L;
nt=length(t);
figure(1)
[~,id]=max(abs(y(round((1:n-2)*length(t)/(n-2)),1:n-2).'));
plot(x,y(round(nt/4),1:n-2),x,y(round(nt/2),1:n-2),x,y(round(3*nt/4),1:n-2),x,y(nt,1:n-2))
hold on
plot(x(id).',y(sub2ind(size(y),round((1:n-2)*length(t)/(n-2)),id).'),'--')
hold off
xlabel("distance [m]") ; title("résolution de l'équation des télégraphistes");
ylabel("tension [V]")
tp=round(t(round([nt/4,nt/2,3*nt/4,nt]))*1e9);
legend(strcat('t = ',num2str(tp(1)),' ns'),strcat('t = ',num2str(tp(2)),' ns'),...
    strcat('t = ',num2str(tp(3)),' ns'),strcat('t = ',num2str(tp(4)),' ns'),'amplitude')
grid on
%% 5) Animation
% Si la version de Matlab le supporte, on peut même faire une petite animation 
% :

figure(2)
for i=1:10:nt
   plot(x,y(i,1:n-2))

   title(['t = ',num2str(round(t(i)*1e9)),' ns'])
   grid on
   axis([0 L -1 1]);
   drawnow
end
%% 
% 
%% Annexe : fonction f à rentrer dans le solveur Matlab

function dIdt=ODE_telegraphistes(t,I)
    global l c r g n Delta largeur Ta
    
    % Condition limite en x=0 (cosinus)
    if t<Ta*largeur; Ix0=0.5-0.5*cos(t/(Ta*largeur)*2*pi);
    else ; Ix0=0;
    end
    
    % Condition limite en x=0 (triangle)
    %if t<Tf/20; Ix0=20*t/Tf; 
    %elseif t<Tf/10 ; Ix0=1-20*(t-Tf/20)/Tf;
    %else ;  Ix0=0;
    %end
    
    % Condition limite en x=L
    IxL=0;
    %if t<Ta*largeur; IxL=-(0.5-0.5*cos(t/(Ta*largeur)*2*pi));
    %else ; IxL=0;
    %end
    
    i=I(1:n-2);
    didt=I(n-1:end);
    d2idt2=Delta/(l*c)*[Ix0;i;IxL]-(r*g)/(l*c)*i-(r*c+l*g)/(l*c)*didt;
    dIdt=[didt;d2idt2];
end
