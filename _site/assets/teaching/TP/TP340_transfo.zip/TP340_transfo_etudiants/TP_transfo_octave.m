%% UE 340 - TP2 - Courant de Foucault

clear ; close
 
% L'objectif est de remplir les différentes fonctions situées ci-après. 
% Les codes associés aux différents tracés sont pré-remplis.

%% 1) Fonctions à remplir

function d=delta(f,mu,sigma)
% donne l'épaisseur de peau (Q 6.1, à remplir)

% ENTREES :
%   - f : fréquence
%   - mu : perméabilité de la tôle
%   - sigma : conductivité de la tôle 


    d=  % à remplir
        
end

function B=champB_serie(x,e,H_exc,f,mu,sigma,N_serie)
% Champ magnétique (Q 6.2)
% donne le phaseur du champ magnétique complexe à partir d'une troncature
% de sa décomposition en série entière

% ENTREES :
%   - x : position dans la tôle (<e/2 et >-e/2)
%   - e : épaisseur de la tôle
%   - H_exc : H =B0/mu au bord de la tôle
%   - f : fréquence
%   - mu : perméabilité de la tôle
%   - sigma : conductivité de la tôle 


    B=  % à  remplir

end

function B=champB_analytique(x,e,H_exc,f,mu,sigma)
% donne le phaseur du champ magnétique complexe à partir de l'expression
% analytique exacte (déjà rempli)

% ENTREES :
%   - x : position dans la tôle (<e/2 et >-e/2)
%   - e : épaisseur de la tôle
%   - H_exc : excitation magnétique au bord de la tôle = B0/mu
%   - f : fréquence
%   - mu : perméabilité de la tôle
%   - sigma : conductivité de la tôle 

    B=H_exc*mu*cosh((1+1j)./delta(f,mu,sigma).*x)./cosh((1+1j)./(2*delta(f,mu,sigma))*e);

end

function phi=fluxB(H_exc,e,S,f,mu,sigma)
% Flux magnétique (Q 6.3, à remplir)
% donne le flux complexe.

% ENTREES :
%   - H_exc : excitation magnétique au bord de la tôle = B0/mu
%   - e : épaisseur de la tôle
%   - S : section totale du circuit magnétique (de l'ensemble des tôles)
%   - f : fréquence
%   - mu : perméabilité de la tôle
%   - sigma : conductivité de la tôle 

phi= . % à remplir
    
end

%% 1) Paramètres matériaux

mu=1000*4e-7*pi;    % Perméabilité magnétique (H/m)
sigma=10e6;         % Conductivité (S/m)
e=1e-3;             % Epaisseur tôle (m)
%% 2) Conditions expérimentales
 
f=100;              % Fréquence (Hz)
i1=0.4;             % Courant primaire (A)
n1=365;             % Nombre de spires primaire
n2=40;              % Nombre de spires secondaire
l=0.216;            % Longueur moyenne circuit magnétique (m)
S=2.16e-3;          % Section circuit magnétique (m^2)
w=2*pi*f;           % Pulsation (rad/s)

%% 3) Tracés 
% a) Tracé de l'amplitude de B dans la tôle

H_exc= % à remplir à l'aide du théorème d'Ampère
N_serie=  % nombre de termes dans la série (à faire varier)

% Tracé de l'expression approchée par une série entière tronquée :
x=linspace(-e/2,e/2,100);
figure()
plot(x*1e3,abs(champB_serie(x,e,H_exc,f,mu,sigma,N_serie)));
hold on
% * *Tracé de l'expression exacte* :
plot(x*1e3,abs(champB_analytique(x,e,H_exc,f,mu,sigma)));
title(['Amplitude du champ B - \delta = ',num2str(delta(f,mu,sigma)*1e3,'%0.2f'),' mm']); ylabel('B [T]'); xlabel('x [mm]');
legend('Expression approchée','Expression exacte')
grid on; hold off

% b) Tracé temporel du courant et de la tension

v2_phaseur= % à remplir à l'aide de la loi de Faraday

t=linspace(0,1/f,100);
v2_complexe=v2_phaseur*exp(1j*w*t);
i1_complexe=i1*exp(1j*w*t);

figure()
subplot(2,1,1)
plot(t,real(i1_complexe)); xlabel('t [s]'); ylabel('courant [A]')
title('Courant primaire imposé')
grid on
subplot(2,1,2)
plot(t,real(v2_complexe)); ylabel('tension [V]'); xlabel('t [s]')
title('Tension secondaire mesurée')
grid on

% c) Tracé du cycle d'hystérésis

Bmoy= % à remplir à partir du flux
mu_app= % à remplir à partir de Bmoy et de H_exc

figure()
H_apparent_complexe=H_exc*exp(1j*w*t);
B_apparent_complexe=Bmoy*exp(1j*w*t);
plot(real(H_apparent_complexe),real(B_apparent_complexe));
title(['Courbe B-H - permeabilité complexe = ',num2str(mu_app,'%.2e')]); xlabel('H [A/m]'); ylabel('B [T]');
grid on

%% 4) Tracés évolués
% a) Tracés de l'amplitude de B dans la tôle en fonction de la fréquence

figure()
hold on
for f=logspace(1,5,6)
    plot(x*1e3,abs(champB_analytique(x,e,H_exc,f,mu,sigma)),"DisplayName",strcat(num2str(f,'%.2f'),' Hz'));
end
hold off
legend("Location","best"); title('Amplitude du champ B'); ylabel('B [T]'); xlabel('x [mm]');
grid on

% b) Tracés de l'épaisseur de peau en fonction de la fréquence

semilogx(logspace(1,5,50),1e3*delta(logspace(1,5,50),mu,sigma))
title('Epaisseur de peau en fonction de la fréquence'); ylabel('\delta [mm]'); xlabel('f [Hz]');
grid on

% c) Tracés des cycles d'hysteresis en fonction de la fréquence (H fixé)

figure()
hold on
for f=logspace(1,3,5)
    Bmoy=fluxB(H_exc,e,S,f,mu,sigma)/S;
    t=linspace(0,1/f,100);
    H_apparent_complexe=H_exc*exp(2j*pi*f*t);
    B_apparent_complexe=Bmoy*exp(2j*pi*f*t);
    plot(real(H_apparent_complexe),real(B_apparent_complexe),"DisplayName",strcat(num2str(f,'%.2f'),' Hz'));
end
hold off
legend("Location","best"); title('Courbe B-H en fonction de la fréquence (|H| fixé)'); xlabel('H [A/m]'); ylabel('B [T]');
grid on

% d) Tracés des cycles d'hysteresis en fonction de la fréquence (B fixé)

Bmoy0=1; % valeur de l'amplitude du champ moyen

figure()
hold on
for f=logspace(1,3,5)
    t=linspace(0,1/f,100);
    H_exc=n1*i1/l;
    Bmoy=fluxB(H_exc,e,S,f,mu,sigma)/S;
    while abs(Bmoy)<Bmoy0-0.01 
        H_exc=H_exc+10;
        Bmoy=fluxB(H_exc,e,S,f,mu,sigma)/S;
    end
    H_apparent_complexe=H_exc*exp(2j*pi*f*t);
    B_apparent_complexe=Bmoy*exp(2j*pi*f*t);
    plot(real(H_apparent_complexe),real(B_apparent_complexe),"DisplayName",strcat(num2str(f,'%.2f'),' Hz'));
end
H_exc=n1*i1/l;
hold off
legend("Location","best"); title('Courbe B-H en fonction de la fréquence (|B| fixé)'); xlabel('H [A/m]'); ylabel('B [T]');
grid on

% e) Tracé de la perméabilité relative complexe en fonction de la fréquence

k=1;
for f=logspace(1,4,50)
    mu_r(k)=(fluxB(H_exc,e,S,f,mu,sigma)/S)./(4e-7*pi*H_exc);
    k=k+1;
end
subplot(2,1,1)
semilogx(logspace(1,4,50),abs(mu_r))
title('|\mu_r| en fonction de la fréquence'); ylabel('|\mu_r| '); xlabel('f [Hz]');
grid on
subplot(2,1,2)
semilogx(logspace(1,4,50),angle(mu_r)*180/pi)
title('arg(\mu_r) en fonction de la fréquence'); ylabel('arg(\mu_r) [°]'); xlabel('f [Hz]');
grid on
